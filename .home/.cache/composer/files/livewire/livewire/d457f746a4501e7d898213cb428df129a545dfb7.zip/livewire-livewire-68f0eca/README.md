### Livewire 3

> Better README coming soon after I'm home from Laracon lol.

### Setup locally

(This is a WIP)

* `git clone`
* `composer install`
* `./vendor/bin/testbench-dusk dusk:chrome-driver`
* (`./vendor/bin/dusk-updater update` also sometimes fixes chromedriver issues)

* `npm install`
* (link all the missing Alpine dependancies)
* `npm run build`

