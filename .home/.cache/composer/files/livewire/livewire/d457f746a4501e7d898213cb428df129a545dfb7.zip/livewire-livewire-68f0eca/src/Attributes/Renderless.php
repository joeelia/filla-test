<?php

namespace Livewire\Attributes;

use Livewire\Mechanisms\HandleComponents\Renderless as BaseRenderless;

#[\Attribute]
class Renderless extends BaseRenderless
{
    //
}
