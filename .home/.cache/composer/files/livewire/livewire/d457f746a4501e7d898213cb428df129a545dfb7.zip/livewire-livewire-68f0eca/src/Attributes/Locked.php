<?php

namespace Livewire\Attributes;

use Livewire\Features\SupportLockedProperties\Locked as BaseLocked;

#[\Attribute]
class Locked extends BaseLocked
{
    //
}
