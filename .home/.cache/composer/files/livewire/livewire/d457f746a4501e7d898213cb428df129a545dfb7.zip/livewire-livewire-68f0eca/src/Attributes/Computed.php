<?php

namespace Livewire\Attributes;

use Livewire\Features\SupportComputed\Computed as BaseComputed;

#[\Attribute]
class Computed extends BaseComputed
{
    //
}
