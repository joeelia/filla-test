<?php

namespace Livewire\Attributes;

use Livewire\Features\SupportPageComponents\Layout as BaseLayout;

#[\Attribute]
class Layout extends BaseLayout
{
    //
}
