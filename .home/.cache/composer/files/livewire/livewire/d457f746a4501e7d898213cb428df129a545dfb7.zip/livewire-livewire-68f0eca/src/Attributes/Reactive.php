<?php

namespace Livewire\Attributes;

use Livewire\Features\SupportReactiveProps\Reactive as BaseReactive;

#[\Attribute]
class Reactive extends BaseReactive
{
    //
}
