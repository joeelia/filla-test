<?php

namespace Livewire\Attributes;

use Livewire\Features\SupportQueryString\Url as BaseUrl;

#[\Attribute]
class Url extends BaseUrl
{
    //
}
