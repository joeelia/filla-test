<?php

namespace Livewire\Attributes;

use Livewire\Features\SupportPageComponents\Title as BaseTitle;

#[\Attribute]
class Title extends BaseTitle
{
    //
}
