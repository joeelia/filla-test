<?php

namespace Livewire\Attributes;

use Livewire\Features\SupportWireModelingNestedComponents\Modelable as BaseModelable;

#[\Attribute]
class Modelable extends BaseModelable
{
    //
}
