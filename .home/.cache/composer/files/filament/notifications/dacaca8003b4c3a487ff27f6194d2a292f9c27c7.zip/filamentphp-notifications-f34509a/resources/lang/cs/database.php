<?php

return [

    'modal' => [

        'heading' => 'Moje aktualizace',

        'actions' => [

            'clear' => [
                'label' => 'Odstranit',
            ],

            'mark_all_as_read' => [
                'label' => 'Označit vše jako přečtené',
            ],

        ],

        'empty' => [
            'heading' => 'Nemáme pro vás žádné aktulizace',
            'description' => 'Zkuste to prosím později',
        ],

    ],

];
