<?php

return [

    'modal' => [

        'heading' => 'Értesítések',

        'actions' => [

            'clear' => [
                'label' => 'Törlés',
            ],

            'mark_all_as_read' => [
                'label' => 'Összes olvasottnak jelölése',
            ],

        ],

        'empty' => [
            'heading' => 'Nincs értesítés',
            'description' => 'Kérjük, ellenőrizze később újra.',
        ],

    ],

];
