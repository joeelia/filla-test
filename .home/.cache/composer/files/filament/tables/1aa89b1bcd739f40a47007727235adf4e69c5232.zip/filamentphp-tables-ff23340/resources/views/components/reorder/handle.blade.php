<x-filament::icon-button
    color="gray"
    icon="heroicon-m-bars-2"
    icon-alias="tables::reorder.button"
    :attributes="\Filament\Support\prepare_inherited_attributes($attributes)"
/>
