<?php

namespace Filament\Tables\Commands\Concerns;

use Filament\Support\Commands\Concerns\CanValidateInput as BaseTrait;

/**
 * @deprecated Use `\Filament\Support\Commands\Concerns\CanValidateInput` instead.
 */
trait CanValidateInput
{
    use BaseTrait;
}
