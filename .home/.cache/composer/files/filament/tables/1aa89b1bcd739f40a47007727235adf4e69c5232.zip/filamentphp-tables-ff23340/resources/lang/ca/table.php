<?php

return [

    'fields' => [

        'search' => [
            'label' => 'Cerca',
            'placeholder' => 'Cerca',
        ],

    ],

    'actions' => [

        'filter' => [
            'label' => 'Filtre',
        ],

        'open_bulk_actions' => [
            'label' => 'Open actions',
        ],

    ],

    'empty' => [
        'heading' => 'No s\'han trobat registres.',
    ],

    'selection_indicator' => [

        'actions' => [

            'select_all' => [
                'label' => 'Select all :count',
            ],

        ],

    ],

];
