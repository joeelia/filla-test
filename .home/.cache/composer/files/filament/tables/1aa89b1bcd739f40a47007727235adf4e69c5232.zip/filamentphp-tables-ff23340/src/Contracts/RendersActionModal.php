<?php

namespace Filament\Tables\Contracts;

interface RendersActionModal
{
}
