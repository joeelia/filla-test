<?php

return [

    'title' => '檢視 :label',

    'breadcrumb' => '檢視',

];
