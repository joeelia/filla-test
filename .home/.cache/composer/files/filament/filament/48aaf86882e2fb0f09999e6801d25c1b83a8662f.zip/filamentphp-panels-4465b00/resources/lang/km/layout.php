<?php

return [

    'direction' => 'ទិសដៅពីឆ្វេងទៅស្ដាំ',

    'actions' => [

        'logout' => [
            'label' => 'ចាកចេញពីកម្មវិធីប្រព័ន្ធ',
        ],

        'open_user_menu' => [
            'label' => 'ម៉ឺនុយអ្នកប្រើ',
        ],

    ],

];
