<?php

return [

    'actions' => [

        'logout' => [
            'label' => 'ចាកចេញពីកម្មវិធីប្រព័ន្ធ',
        ],

    ],

    'welcome' => 'សូមស្វាគមន៍',

];
