<?php

return [

    'title' => ':label 详情',

    'breadcrumb' => '详情',

    'form' => [

        'tab' => [
            'label' => '视图',
        ],

    ],

];
