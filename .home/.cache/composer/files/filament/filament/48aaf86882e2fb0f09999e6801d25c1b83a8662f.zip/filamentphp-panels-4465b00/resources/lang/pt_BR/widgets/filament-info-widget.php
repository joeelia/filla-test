<?php

return [

    'actions' => [

        'open_documentation' => [
            'label' => 'Documentação',
        ],

        'open_github' => [
            'label' => 'GitHub',
        ],

    ],

];
