<?php

return [

    'field' => [
        'label' => '全局搜索',
        'placeholder' => '搜索',
    ],

    'no_results_message' => '未找到搜索结果。',

];
