<?php

return [

    'field' => [
        'label' => 'Genel arama',
        'placeholder' => 'Ara',
    ],

    'no_results_message' => 'Sonuç bulunamadı.',

];
