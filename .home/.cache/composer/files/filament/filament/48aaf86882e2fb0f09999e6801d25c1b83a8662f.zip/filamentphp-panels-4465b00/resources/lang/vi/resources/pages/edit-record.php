<?php

return [

    'title' => 'Chỉnh sửa :label',

    'breadcrumb' => 'Chỉnh sửa',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'Quay lại',
            ],

            'save' => [
                'label' => 'Lưu thay đổi',
            ],

        ],

    ],

    'content' => [

        'tab' => [
            'label' => 'Chỉnh sửa',
        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Đã lưu',
        ],

    ],

];
