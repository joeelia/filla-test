<?php

return [

    'field' => [
        'label' => 'Pesquisa global',
        'placeholder' => 'Pesquisar',
    ],

    'no_results_message' => 'Nenhum resultado encontrado',

];
