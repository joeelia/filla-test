<?php

return [

    'title' => 'ផ្ទាំងគ្រប់គ្រងទូទៅ',

];
