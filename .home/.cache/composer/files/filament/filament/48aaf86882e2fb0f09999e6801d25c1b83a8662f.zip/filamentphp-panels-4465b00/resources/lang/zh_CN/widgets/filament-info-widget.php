<?php

return [

    'actions' => [

        'open_documentation' => [
            'label' => '文档',
        ],

        'open_github' => [
            'label' => 'GitHub',
        ],

    ],

];
