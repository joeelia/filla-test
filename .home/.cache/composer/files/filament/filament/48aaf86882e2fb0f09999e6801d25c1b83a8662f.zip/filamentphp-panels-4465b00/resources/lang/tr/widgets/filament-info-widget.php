<?php

return [

    'actions' => [

        'open_documentation' => [
            'label' => 'Dökümantasyon',
        ],

        'open_github' => [
            'label' => 'GitHub',
        ],

    ],

];
