<?php

return [

    'actions' => [

        'open_documentation' => [
            'label' => 'پەڕگەی یارماتیدەر',
        ],

        'open_github' => [
            'label' => 'گیت هەب',
        ],

    ],

];
