<?php

return [

    'title' => 'دەستکاری :label',

    'breadcrumb' => 'دەستکاری',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'ڕەتکردنەوە',
            ],

            'save' => [
                'label' => 'هەڵگرتن',
            ],

        ],

        'tab' => [
            'label' => 'دەستکاری',
        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'هەڵگیرا',
        ],

    ],

];
