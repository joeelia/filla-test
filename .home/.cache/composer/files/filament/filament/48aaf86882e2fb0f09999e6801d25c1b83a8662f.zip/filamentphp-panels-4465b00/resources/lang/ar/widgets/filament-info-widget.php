<?php

return [

    'actions' => [

        'open_documentation' => [
            'label' => 'التوثيق',
        ],

        'open_github' => [
            'label' => 'GitHub',
        ],

    ],

];
