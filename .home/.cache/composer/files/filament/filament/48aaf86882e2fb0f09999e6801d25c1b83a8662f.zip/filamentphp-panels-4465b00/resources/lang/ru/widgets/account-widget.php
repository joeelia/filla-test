<?php

return [

    'actions' => [

        'logout' => [
            'label' => 'Выход',
        ],

    ],

    'welcome' => 'Добро пожаловать',

];
