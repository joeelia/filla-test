<?php

return [

    'title' => 'Перегляд :label',

    'breadcrumb' => 'Перегляд',

    'content' => [

        'tab' => [
            'label' => 'Перегляд',
        ],

    ],

];
