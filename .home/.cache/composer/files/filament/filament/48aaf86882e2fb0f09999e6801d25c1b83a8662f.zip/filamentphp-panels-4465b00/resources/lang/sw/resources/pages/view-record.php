<?php

return [

    'title' => 'Angalia :label',

    'breadcrumb' => 'Angalia',

    'content' => [

        'tab' => [
            'label' => 'Angalia',
        ],

    ],

];
