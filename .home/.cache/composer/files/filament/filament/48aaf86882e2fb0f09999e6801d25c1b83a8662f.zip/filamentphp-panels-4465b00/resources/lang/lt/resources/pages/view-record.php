<?php

return [

    'title' => 'Peržiūrėti :label',

    'breadcrumb' => 'Peržiūrėti',

    'content' => [

        'tab' => [
            'label' => 'Peržiūrėti',
        ],

    ],

];
