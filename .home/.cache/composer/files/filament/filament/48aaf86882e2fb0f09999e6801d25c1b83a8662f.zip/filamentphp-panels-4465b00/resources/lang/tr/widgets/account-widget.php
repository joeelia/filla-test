<?php

return [

    'actions' => [

        'logout' => [
            'label' => 'Oturumu kapat',
        ],

    ],

    'welcome' => 'Hoş geldin',

];
