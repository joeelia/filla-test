<?php

return [

    'actions' => [

        'open_documentation' => [
            'label' => '說明文件',
        ],

        'open_github' => [
            'label' => 'GitHub',
        ],

    ],

];
