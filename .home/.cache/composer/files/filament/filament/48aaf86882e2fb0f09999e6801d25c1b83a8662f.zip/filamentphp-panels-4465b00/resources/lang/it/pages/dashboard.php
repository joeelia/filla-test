<?php

return [

    'title' => 'Pannello',

];
