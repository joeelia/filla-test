<?php

return [

    'title' => '编辑 :label',

    'breadcrumb' => '编辑',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => '取消',
            ],

            'save' => [
                'label' => '保存',
            ],

        ],

        'tab' => [
            'label' => '编辑',
        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => '已保存',
        ],

    ],

];
