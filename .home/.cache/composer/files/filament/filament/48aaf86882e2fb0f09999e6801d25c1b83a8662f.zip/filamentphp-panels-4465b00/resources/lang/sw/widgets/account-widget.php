<?php

return [

    'actions' => [

        'logout' => [
            'label' => 'Toka',
        ],

    ],

    'welcome' => 'Karibu',

];
