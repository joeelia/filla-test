<?php

return [

    'title' => ':label oluştur',

    'breadcrumb' => 'Oluştur',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'İptal',
            ],

            'create' => [
                'label' => 'Oluştur',
            ],

            'create_another' => [
                'label' => 'Oluştur & yeni oluştur',
            ],

        ],

    ],

    'notifications' => [

        'created' => [
            'title' => 'Oluşturuldu',
        ],

    ],

];
