<?php

return [

    'field' => [
        'label' => '全域搜尋',
        'placeholder' => '搜尋',
    ],

    'no_results_message' => '無搜尋結果。',

];
