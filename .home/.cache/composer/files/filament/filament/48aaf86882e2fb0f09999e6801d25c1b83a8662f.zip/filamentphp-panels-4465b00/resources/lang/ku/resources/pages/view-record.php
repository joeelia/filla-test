<?php

return [

    'title' => 'سەیرکردن :label',

    'breadcrumb' => 'سەیرکردن',

    'form' => [

        'tab' => [
            'label' => 'بینین',
        ],

    ],

];
