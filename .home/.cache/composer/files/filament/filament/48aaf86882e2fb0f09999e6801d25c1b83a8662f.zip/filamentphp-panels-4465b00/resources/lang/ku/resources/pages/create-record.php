<?php

return [

    'title' => 'دروستکردن',

    'breadcrumb' => 'دروستکردن',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'ڕەتکردنەوە',
            ],

            'create' => [
                'label' => 'دروستکردن',
            ],

            'create_another' => [
                'label' => 'دروستکردن و دانەیەکی تر',
            ],

        ],

    ],

    'notifications' => [

        'created' => [
            'title' => 'دروستکرا',
        ],

    ],

];
