<?php

return [

    'actions' => [

        'logout' => [
            'label' => '登出',
        ],

    ],

    'welcome' => '歡迎',

];
