<?php

return [

    'title' => 'Xem :label',

    'breadcrumb' => 'Xem',

    'content' => [

        'tab' => [
            'label' => 'Xem',
        ],

    ],

];
