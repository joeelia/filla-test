<?php

return [

    'actions' => [

        'open_documentation' => [
            'label' => 'Nyaraka',
        ],

        'open_github' => [
            'label' => 'GitHub',
        ],

    ],

];
