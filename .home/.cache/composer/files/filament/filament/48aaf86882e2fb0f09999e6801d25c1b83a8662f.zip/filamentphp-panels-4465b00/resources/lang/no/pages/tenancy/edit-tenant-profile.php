<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'Lagre endringer',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Lagret',
        ],

    ],

];
