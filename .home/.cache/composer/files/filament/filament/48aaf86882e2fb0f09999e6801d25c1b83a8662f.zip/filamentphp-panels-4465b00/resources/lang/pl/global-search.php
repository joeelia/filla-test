<?php

return [

    'field' => [
        'label' => 'Wyszukiwanie globalne',
        'placeholder' => 'Szukaj',
    ],

    'no_results_message' => 'Nie znaleziono wyników.',

];
