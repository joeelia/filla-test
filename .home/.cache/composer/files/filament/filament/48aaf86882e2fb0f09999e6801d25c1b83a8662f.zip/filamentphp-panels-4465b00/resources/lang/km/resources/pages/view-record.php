<?php

return [

    'title' => 'ស្លាក​សញ្ញា :label',

    'breadcrumb' => 'ស្លាក​សញ្ញា',

];
