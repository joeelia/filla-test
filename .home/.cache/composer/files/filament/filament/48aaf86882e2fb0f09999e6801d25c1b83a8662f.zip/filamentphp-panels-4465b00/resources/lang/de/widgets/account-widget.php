<?php

return [

    'actions' => [

        'logout' => [
            'label' => 'Abmelden',
        ],

    ],

    'welcome' => 'Willkommen',

];
