<?php

return [

    'title' => 'Papan pemuka',

];
