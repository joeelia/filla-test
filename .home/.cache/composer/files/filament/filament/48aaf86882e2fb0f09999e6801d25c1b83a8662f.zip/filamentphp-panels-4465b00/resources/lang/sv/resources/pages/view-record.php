<?php

return [

    'title' => 'Visa :label',

    'breadcrumb' => 'Visa',

    'content' => [

        'tab' => [
            'label' => 'Visa',
        ],

    ],

];
