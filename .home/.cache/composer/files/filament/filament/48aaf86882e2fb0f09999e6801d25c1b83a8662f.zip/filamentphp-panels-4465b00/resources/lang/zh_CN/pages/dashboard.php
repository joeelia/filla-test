<?php

return [

    'title' => '仪表板',

];
