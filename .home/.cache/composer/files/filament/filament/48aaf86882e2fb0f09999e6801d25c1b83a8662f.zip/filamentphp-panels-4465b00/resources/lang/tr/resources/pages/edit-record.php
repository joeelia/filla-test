<?php

return [

    'title' => ':label düzenle',

    'breadcrumb' => 'Düzenle',

    'form' => [

        'actions' => [

            'cancel' => [
                'label' => 'İptal',
            ],

            'save' => [
                'label' => 'Kaydet',
            ],

        ],

        'tab' => [
            'label' => 'Düzenle',
        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'Kaydedildi',
        ],

    ],

];
