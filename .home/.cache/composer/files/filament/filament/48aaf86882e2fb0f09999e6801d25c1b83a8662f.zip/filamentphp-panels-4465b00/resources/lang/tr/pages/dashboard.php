<?php

return [

    'title' => 'Panel',

];
