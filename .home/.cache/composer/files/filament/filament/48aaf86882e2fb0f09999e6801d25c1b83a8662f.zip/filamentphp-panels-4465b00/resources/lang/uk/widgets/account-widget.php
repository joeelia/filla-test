<?php

return [

    'actions' => [

        'logout' => [
            'label' => 'Вийти',
        ],

    ],

    'welcome' => 'Вітаємо',

];
