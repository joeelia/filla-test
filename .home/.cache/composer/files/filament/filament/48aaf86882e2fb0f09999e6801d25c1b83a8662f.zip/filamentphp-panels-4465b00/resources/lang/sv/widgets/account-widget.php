<?php

return [

    'actions' => [

        'logout' => [
            'label' => 'Logga ut',
        ],

    ],

    'welcome' => 'Välkommen',

];
