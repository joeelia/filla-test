<?php

return [

    'actions' => [

        'open_documentation' => [
            'label' => 'Tài liệu',
        ],

        'open_github' => [
            'label' => 'GitHub',
        ],

    ],

];
