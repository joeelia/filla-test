<?php

return [

    'actions' => [

        'logout' => [
            'label' => 'Đăng xuất',
        ],

    ],

    'welcome' => 'Chào',

];
