<?php

return [

    'field' => [
        'label' => '전체 검색',
        'placeholder' => '검색',
    ],

    'no_results_message' => '검색 결과가 없습니다.',

];
