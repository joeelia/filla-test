<?php

return [

    'breadcrumb' => 'Перегляд',

];
