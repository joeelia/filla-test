<?php

return [

    'actions' => [

        'logout' => [
            'label' => '退出登录',
        ],

    ],

    'welcome' => '欢迎',

];
