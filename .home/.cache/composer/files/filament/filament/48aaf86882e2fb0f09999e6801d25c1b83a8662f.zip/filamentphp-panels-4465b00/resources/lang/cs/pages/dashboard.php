<?php

return [

    'title' => 'Nástěnka',

];
