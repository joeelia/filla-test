<?php

return [

    'title' => 'Escritorio',

];
