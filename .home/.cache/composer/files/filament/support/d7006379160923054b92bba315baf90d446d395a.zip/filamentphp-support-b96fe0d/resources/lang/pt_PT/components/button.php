<?php

return [

    'messages' => [
        'uploading_file' => 'A enviar ficheiro...',
    ],

];
