<?php

return [

    'messages' => [
        'copied' => 'Скопировано',
    ],

];
