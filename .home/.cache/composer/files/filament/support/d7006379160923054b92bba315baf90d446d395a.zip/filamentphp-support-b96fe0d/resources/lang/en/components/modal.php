<?php

return [

    'actions' => [

        'close' => [
            'label' => 'Close',
        ],

    ],

];
