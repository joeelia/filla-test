<?php

namespace Filament\Support\Contracts;

interface HasLabel
{
    public function getLabel(): ?string;
}
