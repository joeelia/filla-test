<?php

namespace Filament\Support\Enums;

enum ActionSize
{
    case ExtraSmall;

    case Small;

    case Medium;

    case Large;

    case ExtraLarge;
}
