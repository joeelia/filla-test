<?php

namespace Filament\Support\Enums;

enum VerticalAlignment
{
    case Start;

    case Center;

    case End;
}
