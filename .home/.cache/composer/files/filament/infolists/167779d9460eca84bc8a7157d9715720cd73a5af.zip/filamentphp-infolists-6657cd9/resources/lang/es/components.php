<?php

return [

    'text' => [
        'more_list_items' => 'y :count más',
    ],

];
