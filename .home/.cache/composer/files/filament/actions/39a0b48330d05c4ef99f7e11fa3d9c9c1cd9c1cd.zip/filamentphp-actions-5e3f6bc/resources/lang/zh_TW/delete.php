<?php

return [

    'single' => [

        'label' => '刪除',

        'modal' => [

            'heading' => '刪除 :label',

            'actions' => [

                'delete' => [
                    'label' => '刪除',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => '已刪除',
            ],

        ],

    ],

    'multiple' => [

        'label' => '刪除所選的項目',

        'modal' => [

            'heading' => '刪除所選的 :label',

            'actions' => [

                'delete' => [
                    'label' => '刪除',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => '已刪除',
            ],

        ],

    ],

];
