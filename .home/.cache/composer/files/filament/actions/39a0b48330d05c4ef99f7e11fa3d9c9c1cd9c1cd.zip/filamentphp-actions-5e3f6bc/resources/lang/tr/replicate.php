<?php

return [

    'single' => [

        'label' => 'Çoğalt',

        'modal' => [

            'heading' => ':label çoğalt',

            'actions' => [

                'replicate' => [
                    'label' => 'Çoğalt',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => 'Kayıt çoğaltıldı',
            ],

        ],

    ],

];
