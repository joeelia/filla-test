<?php

return [

    'single' => [

        'label' => 'Unganisha',

        'modal' => [

            'heading' => 'Unganisha :label',

            'fields' => [

                'record_id' => [
                    'label' => 'Rekodi',
                ],

            ],

            'actions' => [

                'associate' => [
                    'label' => 'Unganisha',
                ],

                'associate_another' => [
                    'label' => 'Unganisha na unganisha tena',
                ],

            ],

        ],

        'notifications' => [

            'associated' => [
                'title' => 'Imeunganishwa',
            ],

        ],

    ],

];
