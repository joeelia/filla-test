<?php

return [

    'trigger' => [
        'label' => '动作组',
    ],

];
