<?php

return [

    'single' => [

        'label' => 'Խմբագրել',

        'modal' => [

            'heading' => 'Խմբագրել :label',

            'actions' => [

                'save' => [
                    'label' => 'Պահպանել',
                ],

            ],

        ],

        'notifications' => [

            'saved' => [
                'title' => 'Պահպանվել է',
            ],

        ],

    ],

];
