<?php

return [

    'single' => [

        'label' => 'Создать',

        'modal' => [

            'heading' => 'Создать :label',

            'actions' => [

                'create' => [
                    'label' => 'Создать',
                ],

                'create_another' => [
                    'label' => 'Создать и создать еще один',
                ],

            ],

        ],

        'notifications' => [

            'created' => [
                'title' => 'Создано',
            ],

        ],

    ],

];
