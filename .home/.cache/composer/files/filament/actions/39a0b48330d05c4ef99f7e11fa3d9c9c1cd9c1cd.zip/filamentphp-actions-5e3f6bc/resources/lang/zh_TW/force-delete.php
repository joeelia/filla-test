<?php

return [

    'single' => [

        'label' => '強制刪除',

        'modal' => [

            'heading' => '強制刪除 :label',

            'actions' => [

                'delete' => [
                    'label' => '刪除',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => '已刪除資料',
            ],

        ],

    ],

    'multiple' => [

        'label' => '強制刪除所選的項目',

        'modal' => [

            'heading' => '強制刪除所選的 :label',

            'actions' => [

                'delete' => [
                    'label' => '刪除',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => '已刪除資料',
            ],

        ],

    ],

];
