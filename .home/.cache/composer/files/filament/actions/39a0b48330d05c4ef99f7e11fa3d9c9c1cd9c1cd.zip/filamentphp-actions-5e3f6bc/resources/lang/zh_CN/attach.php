<?php

return [

    'single' => [

        'label' => '附加',

        'modal' => [

            'heading' => '附加 :label',

            'fields' => [

                'record_id' => [
                    'label' => '记录',
                ],

            ],

            'actions' => [

                'attach' => [
                    'label' => '保存',
                ],

                'attach_another' => [
                    'label' => '保存并附加另一个',
                ],

            ],

        ],

        'notifications' => [

            'attached' => [
                'title' => '已附加',
            ],

        ],

    ],

];
