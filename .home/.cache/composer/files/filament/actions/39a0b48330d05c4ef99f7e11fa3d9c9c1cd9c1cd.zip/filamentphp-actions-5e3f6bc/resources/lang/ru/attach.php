<?php

return [

    'single' => [

        'label' => 'Прикрепить',

        'modal' => [

            'heading' => 'Прикрепить :label',

            'fields' => [

                'record_id' => [
                    'label' => 'Запись',
                ],

            ],

            'actions' => [

                'attach' => [
                    'label' => 'Прикрепить',
                ],

                'attach_another' => [
                    'label' => 'Прикрепить и прикрепить еще',
                ],

            ],

        ],

        'notifications' => [

            'attached' => [
                'title' => 'Прикреплено',
            ],

        ],

    ],

];
