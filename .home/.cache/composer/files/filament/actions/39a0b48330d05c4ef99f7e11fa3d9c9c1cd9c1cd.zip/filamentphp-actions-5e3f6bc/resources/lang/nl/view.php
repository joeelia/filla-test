<?php

return [

    'single' => [

        'label' => 'Bekijken',

        'modal' => [

            'heading' => ':Label bekijken',

            'actions' => [

                'close' => [
                    'label' => 'Sluiten',
                ],

            ],

        ],

    ],

];
