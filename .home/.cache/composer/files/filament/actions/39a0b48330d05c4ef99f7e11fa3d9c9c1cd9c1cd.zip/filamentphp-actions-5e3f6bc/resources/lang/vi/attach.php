<?php

return [

    'single' => [

        'label' => 'Đính kèm',

        'modal' => [

            'heading' => 'Đính kèm :label',

            'fields' => [

                'record_id' => [
                    'label' => 'Danh sách',
                ],

            ],

            'actions' => [

                'attach' => [
                    'label' => 'Đình kèm',
                ],

                'attach_another' => [
                    'label' => 'Đính kèm & tiếp tục đính kèm với mục khác',
                ],

            ],

        ],

        'notifications' => [

            'attached' => [
                'title' => 'Đã đính kèm',
            ],

        ],

    ],

];
