<?php

return [

    'single' => [

        'label' => 'Tạo :label mới',

        'modal' => [

            'heading' => 'Tạo :label',

            'actions' => [

                'create' => [
                    'label' => 'Tạo',
                ],

                'create_another' => [
                    'label' => 'Tạo & tiếp tục tạo mới',
                ],

            ],

        ],

        'notifications' => [

            'created' => [
                'title' => 'Đã tạo',
            ],

        ],

    ],

];
