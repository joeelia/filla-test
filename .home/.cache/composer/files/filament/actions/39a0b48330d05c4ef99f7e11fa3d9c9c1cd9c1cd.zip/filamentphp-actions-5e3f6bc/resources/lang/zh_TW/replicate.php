<?php

return [

    'single' => [

        'label' => '複製',

        'modal' => [

            'heading' => '複製 :label',

            'actions' => [

                'replicate' => [
                    'label' => '複製',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => '已複製資料',
            ],

        ],

    ],

];
