<?php

return [

    'single' => [

        'label' => 'Rudisha',

        'modal' => [

            'heading' => 'Rudisha :label',

            'actions' => [

                'restore' => [
                    'label' => 'Rudisha',
                ],

            ],

        ],

        'notifications' => [

            'restored' => [
                'title' => 'Imerudishwa',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Rudisha chaguo',

        'modal' => [

            'heading' => 'Rudisha chaguo :label',

            'actions' => [

                'restore' => [
                    'label' => 'Rudisha',
                ],

            ],

        ],

        'notifications' => [

            'restored' => [
                'title' => 'Imerudishwa',
            ],

        ],

    ],

];
