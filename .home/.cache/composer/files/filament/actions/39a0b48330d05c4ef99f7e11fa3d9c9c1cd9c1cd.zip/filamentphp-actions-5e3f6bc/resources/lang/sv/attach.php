<?php

return [

    'single' => [

        'label' => 'Koppla',

        'modal' => [

            'heading' => 'Koppla :label',

            'fields' => [

                'record_id' => [
                    'label' => 'Rader',
                ],

            ],

            'actions' => [

                'attach' => [
                    'label' => 'Koppla',
                ],

                'attach_another' => [
                    'label' => 'Koppla & koppla en till',
                ],

            ],

        ],

        'notifications' => [

            'attached' => [
                'title' => 'Kopplad',
            ],

        ],

    ],

];
