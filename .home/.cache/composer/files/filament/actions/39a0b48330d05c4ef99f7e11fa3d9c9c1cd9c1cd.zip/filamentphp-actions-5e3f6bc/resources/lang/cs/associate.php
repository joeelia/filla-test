<?php

return [

    'single' => [

        'label' => 'Připojit',

        'modal' => [

            'heading' => 'Připojit :label',

            'fields' => [

                'record_id' => [
                    'label' => 'Záznam',
                ],

            ],

            'actions' => [

                'associate' => [
                    'label' => 'Připojit',
                ],

                'associate_another' => [
                    'label' => 'Připojit & připojit another',
                ],

            ],

        ],

        'notifications' => [

            'associated' => [
                'title' => 'Připojeno',
            ],

        ],

    ],

];
