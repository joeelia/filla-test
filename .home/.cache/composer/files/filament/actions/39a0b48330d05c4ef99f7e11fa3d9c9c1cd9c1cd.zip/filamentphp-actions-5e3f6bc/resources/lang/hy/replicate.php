<?php

return [

    'single' => [

        'label' => 'Կրկնօրինակել',

        'modal' => [

            'heading' => 'Կրկնօրինակել :label',

            'actions' => [

                'replicate' => [
                    'label' => 'Կրկնօրինակել',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => 'Գրառումը կրկնօրինակվել է',
            ],

        ],

    ],

];
