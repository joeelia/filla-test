<?php

return [

    'trigger' => [
        'label' => '動作',
    ],

];
