<?php

return [

    'single' => [

        'label' => 'لێکردنەوە',

        'modal' => [

            'heading' => 'لێکردنەوەی :label',

            'actions' => [

                'detach' => [
                    'label' => 'لێکردنەوە',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'لێکرایەوە',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'دیاریکراوەکان لێبکەرەوە',

        'modal' => [

            'heading' => 'دیاریکراوی :label لێبکەرەوە',

            'actions' => [

                'detach' => [
                    'label' => 'دیاریکراوەکان لێبکەرەوە',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'لێکرایەوە',
            ],

        ],

    ],

];
