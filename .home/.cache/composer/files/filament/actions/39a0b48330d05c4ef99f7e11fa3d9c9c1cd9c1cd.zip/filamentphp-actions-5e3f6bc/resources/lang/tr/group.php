<?php

return [

    'trigger' => [
        'label' => 'Eylemler',
    ],

];
