<?php

return [

    'single' => [

        'label' => 'Monista',

        'modal' => [

            'heading' => 'Monista :label',

            'actions' => [

                'replicate' => [
                    'label' => 'Monista',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => 'Tietue monistettu',
            ],

        ],

    ],

];
