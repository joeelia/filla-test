<?php

return [

    'single' => [

        'label' => 'Vizualizare',

        'modal' => [

            'heading' => 'Vizualizare :label',

            'actions' => [

                'close' => [
                    'label' => 'Închidere',
                ],

            ],

        ],

    ],

];
