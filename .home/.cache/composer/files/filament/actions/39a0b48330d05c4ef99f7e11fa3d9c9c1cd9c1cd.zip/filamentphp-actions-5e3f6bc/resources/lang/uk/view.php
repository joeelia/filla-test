<?php

return [

    'single' => [

        'label' => 'Перегляд',

        'modal' => [

            'heading' => 'Перегляд :label',

            'actions' => [

                'close' => [
                    'label' => 'Закрити',
                ],

            ],

        ],

    ],

];
