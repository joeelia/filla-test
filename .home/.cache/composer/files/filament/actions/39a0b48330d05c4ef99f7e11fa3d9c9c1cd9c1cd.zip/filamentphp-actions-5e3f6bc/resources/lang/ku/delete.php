<?php

return [

    'single' => [

        'label' => 'سڕینەوە',

        'modal' => [

            'heading' => 'سڕینەوەی :label',

            'actions' => [

                'delete' => [
                    'label' => 'سڕینەوە',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'سڕدرایەوە',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'دیاریکراوەکان بسڕەوە',

        'modal' => [

            'heading' => 'دیاریکراوەکانی :label بسڕەوە',

            'actions' => [

                'delete' => [
                    'label' => 'دیاریکراوەکان بسڕەوە',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'سڕدرایەوە',
            ],

        ],

    ],

];
