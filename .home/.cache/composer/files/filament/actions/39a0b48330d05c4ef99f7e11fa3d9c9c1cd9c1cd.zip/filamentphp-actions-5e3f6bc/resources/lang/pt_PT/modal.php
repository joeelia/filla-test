<?php

return [

    'confirmation' => 'Tem a certeza que deseja eliminar este item?',

    'actions' => [

        'cancel' => [
            'label' => 'Cancelar',
        ],

        'confirm' => [
            'label' => 'Confirmar',
        ],

        'submit' => [
            'label' => 'Enviar',
        ],

    ],

];
