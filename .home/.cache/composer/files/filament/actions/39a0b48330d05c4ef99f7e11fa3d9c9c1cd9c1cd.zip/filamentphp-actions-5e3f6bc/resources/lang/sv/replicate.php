<?php

return [

    'single' => [

        'label' => 'Replikera',

        'modal' => [

            'heading' => 'Replikera :label',

            'actions' => [

                'replicate' => [
                    'label' => 'Replikera',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => 'Rad replikerad',
            ],

        ],

    ],

];
