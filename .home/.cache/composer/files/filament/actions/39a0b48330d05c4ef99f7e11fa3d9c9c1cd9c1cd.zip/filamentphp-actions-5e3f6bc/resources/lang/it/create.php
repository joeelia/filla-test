<?php

return [

    'single' => [

        'label' => 'Nuovo',

        'modal' => [

            'heading' => 'Salva :label',

            'actions' => [

                'create' => [
                    'label' => 'Salva',
                ],

                'create_another' => [
                    'label' => 'Salva & crea uno nuovo',
                ],

            ],

        ],

        'notifications' => [

            'created' => [
                'title' => 'Creato',
            ],

        ],

    ],

];
