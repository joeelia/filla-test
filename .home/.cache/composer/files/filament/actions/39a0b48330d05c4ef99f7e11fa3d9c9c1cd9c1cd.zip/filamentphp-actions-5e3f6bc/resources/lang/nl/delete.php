<?php

return [

    'single' => [

        'label' => 'Verwijderen',

        'modal' => [

            'heading' => ':Label verwijderen',

            'actions' => [

                'delete' => [
                    'label' => 'Verwijderen',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Verwijderd',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Geselecteerde verwijderen',

        'modal' => [

            'heading' => 'Geselecteerde :label verwijderen',

            'actions' => [

                'delete' => [
                    'label' => 'Verwijderen',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Verwijderd',
            ],

        ],

    ],

];
