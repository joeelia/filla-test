<?php

return [

    'single' => [

        'label' => 'Atskirti',

        'modal' => [

            'heading' => 'Atskirti :label',

            'actions' => [

                'detach' => [
                    'label' => 'Atskirti',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'Atskirta',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Atskirti pasirinktą',

        'modal' => [

            'heading' => 'Atskirti pasirinktą :label',

            'actions' => [

                'detach' => [
                    'label' => 'Atskirti',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'Atskirta',
            ],

        ],

    ],

];
