<?php

return [

    'single' => [

        'label' => 'Підключити',

        'modal' => [

            'heading' => 'Підключити :label',

            'fields' => [

                'record_id' => [
                    'label' => 'Запис',
                ],

            ],

            'actions' => [

                'associate' => [
                    'label' => 'Підключити',
                ],

                'associate_another' => [
                    'label' => 'Підключити та підключити інше',
                ],

            ],

        ],

        'notifications' => [

            'associated' => [
                'title' => 'Підключено',
            ],

        ],

    ],

];
