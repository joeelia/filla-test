<?php

return [

    'single' => [

        'label' => 'Duplica',

        'notifications' => [

            'replicated' => [
                'title' => 'Duplicato',
            ],

        ],

    ],

];
