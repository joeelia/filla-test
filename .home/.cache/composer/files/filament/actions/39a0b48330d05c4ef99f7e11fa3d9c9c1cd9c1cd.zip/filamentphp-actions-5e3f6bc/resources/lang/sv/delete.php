<?php

return [

    'single' => [

        'label' => 'Radera',

        'modal' => [

            'heading' => 'Radera :label',

            'actions' => [

                'delete' => [
                    'label' => 'Radera',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Raderad',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Radera valda',

        'modal' => [

            'heading' => 'Radera valda :label',

            'actions' => [

                'delete' => [
                    'label' => 'Radera',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Raderade',
            ],

        ],

    ],

];
