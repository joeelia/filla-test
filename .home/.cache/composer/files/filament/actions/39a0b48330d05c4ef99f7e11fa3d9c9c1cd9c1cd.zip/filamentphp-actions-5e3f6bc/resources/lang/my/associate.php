<?php

return [

    'single' => [

        'label' => 'တွဲဘက်',

        'modal' => [

            'heading' => ':label တွဲဘက်',

            'fields' => [

                'record_id' => [
                    'label' => 'မှတ်တမ်းများ',
                ],

            ],

            'actions' => [

                'associate' => [
                    'label' => 'တွဲဘက်',
                ],

                'associate_another' => [
                    'label' => 'သိမ်းဆည်းပြီး နောက်တစ်ခုကို ဖန်တီးပါ',
                ],

            ],

        ],

        'notifications' => [

            'associated' => [
                'title' => 'သိမ်းဆည်းပြီး',
            ],

        ],

    ],

];
