<?php

return [

    'trigger' => [
        'label' => 'Vitendo',
    ],

];
