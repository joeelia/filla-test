<?php

return [

    'confirmation' => 'Ar tikrai tai nori atlikti?',

    'actions' => [

        'cancel' => [
            'label' => 'Atšaukti',
        ],

        'confirm' => [
            'label' => 'Patvirinti',
        ],

        'submit' => [
            'label' => 'Pateikti',
        ],

    ],

];
