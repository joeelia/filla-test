<?php

return [

    'single' => [

        'label' => 'Iga',

        'modal' => [

            'heading' => 'Iga :label',

            'actions' => [

                'replicate' => [
                    'label' => 'Iga',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => 'Imeigwa',
            ],

        ],

    ],

];
