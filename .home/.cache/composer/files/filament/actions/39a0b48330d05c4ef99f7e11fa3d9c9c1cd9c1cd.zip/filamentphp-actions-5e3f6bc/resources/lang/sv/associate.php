<?php

return [

    'single' => [

        'label' => 'Associera',

        'modal' => [

            'heading' => 'Associera :label',

            'fields' => [

                'record_id' => [
                    'label' => 'Rader',
                ],

            ],

            'actions' => [

                'associate' => [
                    'label' => 'Associera',
                ],

                'associate_another' => [
                    'label' => 'Associera & associera en till',
                ],

            ],

        ],

        'notifications' => [

            'associated' => [
                'title' => 'Associerad',
            ],

        ],

    ],

];
