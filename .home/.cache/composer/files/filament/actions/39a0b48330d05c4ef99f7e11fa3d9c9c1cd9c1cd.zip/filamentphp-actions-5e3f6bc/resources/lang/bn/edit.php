<?php

return [

    'single' => [

        'label' => 'সম্পাদন করুন',

        'modal' => [

            'heading' => ':label সম্পাদন করুন',

            'actions' => [

                'save' => [
                    'label' => 'সংরক্ষণ করুন',
                ],

            ],

        ],

        'notifications' => [

            'saved' => [
                'title' => 'সংরক্ষিত হয়েছে',
            ],

        ],

    ],

];
