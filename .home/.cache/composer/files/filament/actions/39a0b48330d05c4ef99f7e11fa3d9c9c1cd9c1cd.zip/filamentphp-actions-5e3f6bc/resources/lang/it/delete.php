<?php

return [

    'single' => [

        'label' => 'Elimina',

        'modal' => [

            'heading' => 'Elimina :label',

            'actions' => [

                'delete' => [
                    'label' => 'Elimina',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Eliminato',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Elimina selezionato',

        'modal' => [

            'heading' => 'Elimina selezionato :label',

            'actions' => [

                'delete' => [
                    'label' => 'Elimina selezionato',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Eliminato',
            ],

        ],

    ],

];
