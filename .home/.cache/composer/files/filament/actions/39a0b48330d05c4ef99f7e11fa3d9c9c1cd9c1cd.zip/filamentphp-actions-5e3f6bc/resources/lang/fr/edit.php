<?php

return [

    'single' => [

        'label' => 'Modifier',

        'modal' => [

            'heading' => 'Modifier :label',

            'actions' => [

                'save' => [
                    'label' => 'Sauvegarder',
                ],

            ],

        ],

        'notifications' => [

            'saved' => [
                'title' => 'Sauvegardé(e)',
            ],

        ],

    ],

];
