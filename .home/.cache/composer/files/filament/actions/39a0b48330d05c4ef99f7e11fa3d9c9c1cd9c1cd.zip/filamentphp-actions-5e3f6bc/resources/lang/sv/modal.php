<?php

return [

    'confirmation' => 'Är du säker på att du vill göra det här?',

    'actions' => [

        'cancel' => [
            'label' => 'Avbryt',
        ],

        'confirm' => [
            'label' => 'Bekräfta',
        ],

        'submit' => [
            'label' => 'Skicka',
        ],

    ],

];
