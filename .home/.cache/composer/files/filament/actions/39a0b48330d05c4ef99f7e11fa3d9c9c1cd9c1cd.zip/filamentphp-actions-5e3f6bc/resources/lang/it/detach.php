<?php

return [

    'single' => [

        'label' => 'Scollega',

        'modal' => [

            'heading' => 'Scollega :label',

            'actions' => [

                'detach' => [
                    'label' => 'Scollega',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'Scollegato',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Scollega selezionato',

        'modal' => [

            'heading' => 'Scollega selezionato :label',

            'actions' => [

                'detach' => [
                    'label' => 'Scollega selezionato',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'Scollegato',
            ],

        ],

    ],

];
