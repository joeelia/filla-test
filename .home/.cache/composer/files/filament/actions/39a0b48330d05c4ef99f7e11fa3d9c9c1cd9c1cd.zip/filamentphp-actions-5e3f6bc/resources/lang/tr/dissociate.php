<?php

return [

    'single' => [

        'label' => 'Ayrıştır',

        'modal' => [

            'heading' => ':label ayrıştır',

            'actions' => [

                'dissociate' => [
                    'label' => 'Ayrıştır',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'Ayrıştırıldı',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Seçiliyi ayrıştır',

        'modal' => [

            'heading' => ':label seçiliyi ayrıştır',

            'actions' => [

                'dissociate' => [
                    'label' => 'Seçiliyi ayrıştır',
                ],

            ],

        ],

        'notifications' => [

            'dissociated' => [
                'title' => 'Ayrıştırıldı',
            ],

        ],

    ],

];
