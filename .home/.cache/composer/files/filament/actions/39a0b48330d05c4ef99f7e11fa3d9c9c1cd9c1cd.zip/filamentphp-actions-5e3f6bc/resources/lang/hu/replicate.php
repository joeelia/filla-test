<?php

return [

    'single' => [

        'label' => 'Duplikálás',

        'modal' => [

            'heading' => ':label duplikálása',

            'actions' => [

                'replicate' => [
                    'label' => 'Duplikálás',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => 'Duplikálva',
            ],

        ],

    ],

];
