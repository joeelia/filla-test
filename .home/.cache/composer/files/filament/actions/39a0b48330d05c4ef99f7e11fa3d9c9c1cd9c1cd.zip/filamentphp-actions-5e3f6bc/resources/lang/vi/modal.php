<?php

return [

    'confirmation' => 'Bạn có chắc chắn khi thực hiện hành động này?',

    'actions' => [

        'cancel' => [
            'label' => 'Huỷ',
        ],

        'confirm' => [
            'label' => 'Xác nhận',
        ],

        'submit' => [
            'label' => 'Gửi',
        ],

    ],

];
