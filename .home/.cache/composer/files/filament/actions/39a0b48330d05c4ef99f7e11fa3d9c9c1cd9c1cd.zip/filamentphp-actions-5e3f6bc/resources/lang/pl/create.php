<?php

return [

    'single' => [

        'label' => 'Utwórz',

        'modal' => [

            'heading' => 'Utwórz :label',

            'actions' => [

                'create' => [
                    'label' => 'Utwórz',
                ],

                'create_another' => [
                    'label' => 'Utwórz i utwórz kolejny',
                ],

            ],

        ],

        'notifications' => [

            'created' => [
                'title' => 'Utworzono',
            ],

        ],

    ],

];
