<?php

return [

    'trigger' => [
        'label' => 'Toimenpiteet',
    ],

];
