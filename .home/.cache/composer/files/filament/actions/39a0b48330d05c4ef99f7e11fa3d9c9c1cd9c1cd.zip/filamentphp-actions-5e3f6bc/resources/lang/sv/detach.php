<?php

return [

    'single' => [

        'label' => 'Koppla loss',

        'modal' => [

            'heading' => 'Koppla loss :label',

            'actions' => [

                'detach' => [
                    'label' => 'Koppla loss',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'Koppling släppt',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Koppla loss valda',

        'modal' => [

            'heading' => 'Koppla loss valda :label',

            'actions' => [

                'detach' => [
                    'label' => 'Koppla loss valda',
                ],

            ],

        ],

        'notifications' => [

            'detached' => [
                'title' => 'Koppling släppt',
            ],

        ],

    ],

];
