<?php

return [

    'confirmation' => 'Ви впевнені, що хочете це зробити?',

    'actions' => [

        'cancel' => [
            'label' => 'Скасувати',
        ],

        'confirm' => [
            'label' => 'Підтвердити',
        ],

        'submit' => [
            'label' => 'Відправити',
        ],

    ],

];
