<?php

return [

    'single' => [

        'label' => 'دەستکاری',

        'modal' => [

            'heading' => 'دەستکاری :label',

            'actions' => [

                'save' => [
                    'label' => 'هەڵگرتن',
                ],

            ],

        ],

        'notifications' => [

            'saved' => [
                'title' => 'هەڵگیرا',
            ],

        ],

    ],

];
