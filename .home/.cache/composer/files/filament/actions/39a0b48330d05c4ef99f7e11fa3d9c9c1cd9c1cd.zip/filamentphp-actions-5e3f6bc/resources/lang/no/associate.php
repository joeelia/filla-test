<?php

return [

    'single' => [

        'label' => 'Assosiere',

        'modal' => [

            'heading' => 'Assosiere :label',

            'fields' => [

                'record_id' => [
                    'label' => 'Post',
                ],

            ],

            'actions' => [

                'associate' => [
                    'label' => 'Assosiere',
                ],

                'associate_another' => [
                    'label' => 'Assosiere & assosiere en til',
                ],

            ],

        ],

        'notifications' => [

            'associated' => [
                'title' => 'Assosiert',
            ],

        ],

    ],

];
