<?php

return [

    'single' => [

        'label' => 'Liên kết',

        'modal' => [

            'heading' => 'Liên kết :label',

            'fields' => [

                'record_id' => [
                    'label' => 'Danh sách',
                ],

            ],

            'actions' => [

                'associate' => [
                    'label' => 'Liên kết',
                ],

                'associate_another' => [
                    'label' => 'Liên kết & tiếp tục liên kết với mục khác',
                ],

            ],

        ],

        'notifications' => [
            'associated' => 'Đã liên kết',
        ],

    ],

];
