<?php

return [

    'single' => [

        'label' => 'Powiel',

        'modal' => [

            'heading' => 'Powiel :label',

            'actions' => [

                'replicate' => [
                    'label' => 'Powiel',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => 'Powielono',
            ],

        ],

    ],

];
