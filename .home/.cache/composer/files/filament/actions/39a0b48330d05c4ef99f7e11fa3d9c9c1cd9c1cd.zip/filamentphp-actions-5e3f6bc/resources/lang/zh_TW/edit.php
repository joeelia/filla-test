<?php

return [

    'single' => [

        'label' => '編輯',

        'modal' => [

            'heading' => '編輯 :label',

            'actions' => [

                'save' => [
                    'label' => '保存',
                ],

            ],

        ],

        'notifications' => [

            'saved' => [
                'title' => '已保存',
            ],

        ],

    ],

];
