CHANGELOG
=========

6.1
---

 * Add the component as experimental
